#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include "parser.h"
#include "com_stm32f1.h"
#include "stm32f1xx_hal.h"
#include "hw_desc_adc_stm32f1.h"
#include "hw_desc_uart_stm32f1.h"
#include "parserFunction.h"
#include "pcf8574.h"
#include "m41t56_rtc.h"


/********************************************************************************************************************
*													                                                                *
*	                  P R I V A T E S     D E F I N I T I O N    O F    C O N S T A N T S                           *
*   													                                                            *
********************************************************************************************************************/

#define  REQ_BYTE2_1                                          (uint8_t)('1')
#define  REQ_BYTE2_2                                          (uint8_t)('2')
#define  REQ_BYTE2_8                                          (uint8_t)('8')
#define  REQ_BYTE2_9                                          (uint8_t)('9')

#define  RESP_LEN_ID1                                         (uint8_t)8
#define  RESP_LEN_ID4                                         (uint8_t)5
#define  RESP_LEN_ID25                                        (uint8_t)0
#define  RESP_LEN_ID36                                        (uint8_t)1
#define  RESP_LEN_ID37                                        (uint8_t)14
#define  RESP_LEN_ID39                                        (uint8_t)1
#define  RESP_LEN_ID48                                        (uint8_t)1
#define  RESP_LEN_ID49                                        (uint8_t)5

#define  RESP_BYTE2_ID1                                       (uint8_t)9
#define  RESP_BYTE2_ID4                                       (uint8_t)3
#define  RESP_BYTE2_ID25                                      (uint8_t)0
#define  RESP_BYTE2_ID36                                      (uint8_t)2
#define  RESP_BYTE2_ID37                                      (uint8_t)9
#define  RESP_BYTE2_ID39                                      (uint8_t)2
#define  RESP_BYTE2_ID48                                      (uint8_t)2
#define  RESP_BYTE2_ID49                                      (uint8_t)3

#define  DATA_LENGHT_MAX                                      (uint16_t)40
#define  DATA_LENGHT_MIN                                      (uint8_t)1
#define  HEADER_LEN                                           (uint8_t)3
#define  CMD_LEN                                              (uint8_t)1
#define  BYTE2_LEN                                            (uint8_t)1
#define  ADC_CHANNEL_MAX                                      (uint8_t)2

#define  ID_CMD_RELAIS                                        (uint8_t)1
#define  ID_CMD_READ_ADC                                      (uint8_t)4
#define  ID_CMD_UPP_RESET                                     (uint8_t)25
#define  ID_CMD_SWITCH_REMOTE_RELAIS                          (uint8_t)36
#define  ID_CMD_READ_ANALOG_INPUTS                            (uint8_t)37
#define  ID_CMD_I2C_TEST                                      (uint8_t)39
#define  ID_CMD_SET_TIME                                      (uint8_t)48
#define  ID_CMD_GET_TIME                                      (uint8_t)49

#define  UART_BUFFER_SIZE                                     (uint8_t)195
#define  UART_TX_BUFFER_SIZE                                  (uint8_t)40
#define  RESP_SIZE                                            (uint8_t)100
#define  TEMP_BUFFER_SIZE                                     (uint8_t)100
#define  UART_TIME_OUT                                        7000
#define  PARSER_DELIMITER                                     (uint8_t)(';')
#define  PARSER_END_OF_FRAME                                  (uint8_t)('\r')


/********************************************************************************************************************
*													                                                                *
*	                                  T Y P E D E F                                                                 *
*   													                                                            *
********************************************************************************************************************/
/* callback function for parser */
typedef void (*vCmdFunc_t) (const uint8_t *pu8RxBuffer, uint8_t  *pu8TxBuffer);


/********************************************************************************************************************
*													                                                                *
*	                                  E N U M E R A T I O N                                                         *
*   													                                                            *
********************************************************************************************************************/

/**
 * @enum Command list
 *
 */
typedef enum eCmdList_tTag
{
    CMD_RELAIS_1                  = 0,
    CMD_READ_ADC_4                = 1,
    CMD_UPP_RESET_25              = 2,
    CMD_SWITCH_REMOTE_RELAIS_36   = 3,
    CMD_READ_ANALOG_INPUTS_37     = 4,
    CMD_I2C_TEST_39               = 5,
    CMD_SET_TIME_48               = 6,
    CMD_GET_TIME_49               = 7,

    CMD_MAX
} eCmdList_t;


/**
 * @enum Parser state
 *
 */
typedef enum eParserState_tTag
{
	PARSER_STATE_HEADER_U      = 0,
	PARSER_STATE_HEADER_P      = 1,
	PARSER_STATE_BYTE2         = 3,
	PARSER_STATE_CMD           = 4,
	PARSER_STATE_DATA          = 5,
	PARSER_STATE_COMPLETE      = 6,

	PARSER_STATE_MAX
} eParserState_t;

/********************************************************************************************************************
*													                                                                *
*	                                 S T R U C T U R E                                                              *
*   													                                                            *
********************************************************************************************************************/

/**
 * @struct receive frame
 *
 */
typedef struct sRcvFrame_tTag
{
	char           cHeader[HEADER_LEN + 1];      /**< string "PC_" for response command*/
	uint8_t        u8DataLen;                    /**< data length  */
	uint8_t        u8Cmd;                        /**< Command */
	uint8_t        u8Data[DATA_LENGHT_MAX];      /**< data field */
} sRcvFrame_t;


/**
 * @struct Raw message decode
 *
 */
typedef struct sRawMessageDecode_tTag
{
	eParserState_t  eState;          /**< Parser state */
	uint8_t         u8BufferIndex;   /**< data buffer index */
	uint8_t         u8RcvByteCount;  /**< parsed byte */
	uint32_t        u32CurentTime;   /**< current time of timer */
	uint32_t        u32ElapseTime;      /**< uart time out */
	sRcvFrame_t     sFrame;          /**< received frame */
} sRawMessageDecode_t;


/**
 * @struct UART buffer structure
 *
 */
typedef struct sUartBuffer_tTag
{
	uint8_t  u8Data[UART_BUFFER_SIZE];
	uint16_t u16ReadIndex;
	uint16_t u16WriteIndex;
} sUartBuffer_t;


/**
 * @struct command structure
 *
 */
typedef struct cmdParser_tTag
{
	vCmdFunc_t vFunc;
	uint8_t    u8RespLen;
	uint8_t    u8RespByte;
}cmdParser_t;

/********************************************************************************************************************
*													                                                                *
*	          D E C L A R A T I O N        O F        P R I V A T E         V A R I A B L E S                       *
*   													                                                            *
********************************************************************************************************************/

static sUartBuffer_t     sUartRxBuffer;
static uint8_t           u8UartTxBuffer[DATA_LENGHT_MAX] = {0};
static uint8_t           u8DataToSend[RESP_SIZE] = {0};
static char              cBuffer[UART_TX_BUFFER_SIZE] = "";
static sUARTObj_t        sUARTObj;
static sLongType_t       sUnixTime = {0};
static sTIMObj_t*        psTimerInst;
extern I2C_HandleTypeDef hi2c1;
extern I2C_HandleTypeDef hi2c2;
static sUartBuffer_t     sUartRxBuffer;
sADCObj_t                sADCObj;


static sRawMessageDecode_t sMsgDecode =
{
	.eState         = PARSER_STATE_HEADER_U,
	.u8RcvByteCount = 0,
};


static const cmdParser_t cmdParser[CMD_MAX] =
{
	{.vFunc =  vFunctionRelaisID1,           .u8RespLen = RESP_LEN_ID1,   .u8RespByte = RESP_BYTE2_ID1  },
	{.vFunc =  vFunctionReadADCID4,          .u8RespLen = RESP_LEN_ID4,   .u8RespByte = RESP_BYTE2_ID4  },
	{.vFunc =  vFunctionUPPID25,             .u8RespLen = RESP_LEN_ID25,  .u8RespByte = RESP_BYTE2_ID25 },
	{.vFunc = vFunctionSWRemoteRelaisID36,   .u8RespLen = RESP_LEN_ID36,  .u8RespByte = RESP_BYTE2_ID36 },
	{.vFunc = vFunctionReadAnalogInputsID37, .u8RespLen = RESP_LEN_ID37,  .u8RespByte = RESP_BYTE2_ID37 },
	{.vFunc = vFunctionI2CTestID39,          .u8RespLen = RESP_LEN_ID39,  .u8RespByte = RESP_BYTE2_ID39 },
	{.vFunc = vFunctionSetTimeID48,          .u8RespLen = RESP_LEN_ID48,  .u8RespByte = RESP_BYTE2_ID48 },
	{.vFunc = vFunctionGetTimeID49,          .u8RespLen = RESP_LEN_ID49,  .u8RespByte = RESP_BYTE2_ID49 },
};

/********************************************************************************************************************
*													                                                                *
*	          D E C L A R A T I O N        O F     P R I V A T E         F U N C T I O N S                          *
*   													                                                            *
********************************************************************************************************************/

/**
 * @brief  Converts a string to an integer
 *
 * @param str : string to convert
 */
static uint32_t u32StringToInt(const char str[]);

/**
 * @brief  Get lenght of field data
 *
 * @param u8Cmd        : command to send
 */
static uint8_t u8GetRespLen(uint8_t u8Cmd);


/**
 * @brief  Get the word that follows the header word "PC_"
 *
 * @param u8Cmd        : command to send
 */
static uint8_t u8GetByte2(uint8_t u8Cmd);


/**
 * @brief  Get command ID
 *
 * @param u8Cmd   : command
 */
static uint8_t u8GetCmdIndex(uint8_t u8Cmd);


/**
 * @brief   this function decode the receive frame
 * @param   psMsgDecode : pointer to raw frame data
 * @param   ByteIn       : data to read
 * @return      Nothing
 */
static void vMsgDeserialize(sRawMessageDecode_t *psMsgDecode, uint8_t u8ByteIn);


/**
 * @brief   this function send response due an request
 * @param   sRcvMsg : pointer to the received message
 * @return      Nothing
 */
static void vSendResp(const sRcvFrame_t *sRcvMsg);

/********************************************************************************************************************
*													                                                                *
*	          D E F I N I T I O N        O F     P R I V A T E         F U N C T I O N S                            *
*   													                                                            *
********************************************************************************************************************/


/**
 * @brief  Converts a string to an integer
 *
 * @param str : string to convert
 */
static uint32_t u32StringToInt(const char str[])
{
    uint32_t u32Ret = 0;

    /* convert string to integer */
    for (uint16_t u16Idx = 0; str[u16Idx]!= '\0'; u16Idx++)
    {
    	u32Ret = u32Ret * 10 + str[u16Idx] - '0';
    }

    return u32Ret;
}


static uint8_t u8GetRespLen(uint8_t u8Cmd)
{
	uint8_t u8Index = u8GetCmdIndex(u8Cmd);

	return cmdParser[u8Index].u8RespLen;
}


static uint8_t u8GetByte2(uint8_t u8Cmd)
{
  uint8_t u8Index = u8GetCmdIndex(u8Cmd);

  return cmdParser[u8Index].u8RespByte;
}


static uint8_t u8GetCmdIndex(uint8_t u8Cmd)
{
	uint8_t u8Ret = 0;

	switch (u8Cmd)
	{
		case ID_CMD_RELAIS :

			u8Ret = CMD_RELAIS_1;
			break;

		case ID_CMD_READ_ADC :

		    u8Ret = CMD_READ_ADC_4;
		    break;

		case ID_CMD_UPP_RESET :

			u8Ret = CMD_UPP_RESET_25;
			break;

		case ID_CMD_SWITCH_REMOTE_RELAIS :

			u8Ret = CMD_SWITCH_REMOTE_RELAIS_36;
			break;

		case ID_CMD_READ_ANALOG_INPUTS :

			u8Ret = CMD_READ_ANALOG_INPUTS_37;
			break;

		case ID_CMD_I2C_TEST :

			u8Ret = CMD_I2C_TEST_39;
			break;

		case ID_CMD_SET_TIME :

			u8Ret = CMD_SET_TIME_48;
			break;

		case ID_CMD_GET_TIME :

			u8Ret = CMD_GET_TIME_49;
			break;

		default : while(1);
	}

	return u8Ret;
}


static void vMsgDeserialize(sRawMessageDecode_t* const psMsgDecode, uint8_t u8ByteIn)
{
	static uint8_t u8DataLen = 0;
	static uint8_t u8ByteCnt = 0;
	static uint8_t u8Cmd     = 0;

	switch (psMsgDecode->eState)
	{
		case PARSER_STATE_COMPLETE :
			/* do nothing */
		    break;

		case PARSER_STATE_HEADER_U :
		{
			/* Initialization of private variable */
			u8DataLen = 0;
			u8ByteCnt = 0;
			u8Cmd     = 0;

			/* Initialization of private variable */
			u8DataLen = 0;

			/* Initialization of byte counter */
			psMsgDecode->u8RcvByteCount = 0;

			/* Initialization of buffer index */
			psMsgDecode->u8BufferIndex = 0;

			/* Initialization of uart timeout */
			psMsgDecode->u32ElapseTime = 0;

			/* Initialization of buffer */
			memset(cBuffer, 0, sizeof(cBuffer));
			memset(psMsgDecode->sFrame.u8Data, 0, sizeof(psMsgDecode->sFrame.u8Data));

			/* check character U */
			if (u8ByteIn == 'U')
			{
				/* recovery of data */
				psMsgDecode->sFrame.cHeader[psMsgDecode->u8RcvByteCount] = u8ByteIn;

				/* count receive bytes */
				psMsgDecode->u8RcvByteCount++;

				/* go to the next step */
				psMsgDecode->eState = PARSER_STATE_HEADER_P;

				/* Record the current time since the timer was started */
				psMsgDecode->u32CurentTime = psTimerInst->pfu32GetTickMs();
			}

		}

			break;

		case PARSER_STATE_HEADER_P :
		{
			/* compute elapse time */
			psMsgDecode->u32ElapseTime = (psTimerInst->pfu32GetTickMs() - psMsgDecode->u32CurentTime);

			/* check if time elapsed */
			if (psMsgDecode->u32ElapseTime <= UART_TIME_OUT)
			{
				if ((u8ByteIn == 'P') && (psMsgDecode->u8RcvByteCount < HEADER_LEN))
				{
					/* recovery of data */
					psMsgDecode->sFrame.cHeader[psMsgDecode->u8RcvByteCount] = u8ByteIn;

					/* count receive bytes */
					psMsgDecode->u8RcvByteCount++;

					/* Record the current time since the timer was started */
					psMsgDecode->u32CurentTime = psTimerInst->pfu32GetTickMs();
				}
				else if ((u8ByteIn == PARSER_DELIMITER) && (psMsgDecode->u8RcvByteCount == HEADER_LEN))
				{
					/* go to the next step */
					psMsgDecode->eState = PARSER_STATE_BYTE2;

					/* Record the current time since the timer was started */
					psMsgDecode->u32CurentTime = psTimerInst->pfu32GetTickMs();
				}
				else
				{
					/* return to the header state */
					psMsgDecode->eState = PARSER_STATE_HEADER_U;
				}
			}
			else
			{
				/* return to the header state */
				psMsgDecode->eState = PARSER_STATE_HEADER_U;
			}
		}
			break;

		case PARSER_STATE_BYTE2 :
		{
			/* compute elapse time */
			psMsgDecode->u32ElapseTime = (psTimerInst->pfu32GetTickMs() - psMsgDecode->u32CurentTime);

			/* check if time elapsed */
			if (psMsgDecode->u32ElapseTime <= UART_TIME_OUT)
			{
				if ((u8ByteIn == REQ_BYTE2_1) ||
					(u8ByteIn == REQ_BYTE2_2) ||
					(u8ByteIn == REQ_BYTE2_8) ||
					(u8ByteIn == REQ_BYTE2_9))
				{
					/* store data length */
					cBuffer[0] = u8ByteIn;

					/* recovery of data length */
					psMsgDecode->sFrame.u8DataLen = (uint8_t)u32StringToInt(cBuffer);

					/* Initialization of buffer */
					memset(cBuffer, 0, sizeof(cBuffer));

					/* count receive bytes */
					psMsgDecode->u8RcvByteCount++;

					/* Record the current time since the timer was started */
					psMsgDecode->u32CurentTime = psTimerInst->pfu32GetTickMs();
				}
				else if ((u8ByteIn == PARSER_DELIMITER) && (psMsgDecode->u8RcvByteCount == (HEADER_LEN + 1)))
				{
					/* go to the next step */
					psMsgDecode->eState = PARSER_STATE_CMD;

					/* Record the current time since the timer was started */
					psMsgDecode->u32CurentTime = psTimerInst->pfu32GetTickMs();
				}
				else
				{
					/* return to the header state */
					psMsgDecode->eState = PARSER_STATE_HEADER_U;
				}
			}
			else
			{
				/* return to the header state */
				psMsgDecode->eState = PARSER_STATE_HEADER_U;
			}

			break;
		}

		case PARSER_STATE_CMD :
		{
			/* compute elapse time */
			psMsgDecode->u32ElapseTime = (psTimerInst->pfu32GetTickMs() - psMsgDecode->u32CurentTime);

			/* check if time elapsed */
			if (psMsgDecode->u32ElapseTime <= UART_TIME_OUT)
			{
				if (((u8ByteIn >= '1') && (u8ByteIn <= '9')) && (u8ByteCnt < 2))
				{
					/* count receive bytes */
					u8ByteCnt++;

					switch(u8ByteCnt)
					{
						case 1 :
						{
							if ((u8ByteIn >= '1') && (u8ByteIn <= '4'))
							{
								/* store command */
								cBuffer[0] = u8ByteIn;

								/* convert command to integer */
								u8Cmd = (uint8_t)(u8Cmd * 10) + (uint8_t)u32StringToInt(cBuffer);

								/* Initialization of buffer */
								memset(cBuffer, 0, sizeof(cBuffer));

								/* count receive bytes */
								psMsgDecode->u8RcvByteCount++;

								/* Record the current time since the timer was started */
								psMsgDecode->u32CurentTime = psTimerInst->pfu32GetTickMs();
							}
							else
							{
								/* go to the header step */
								psMsgDecode->eState = PARSER_STATE_HEADER_U;
							}
						}
							break;

						case 2 :
						{
							if ((u8ByteIn >= '5') && (u8ByteIn <= '9'))
							{
								/* store command */
								cBuffer[0] = u8ByteIn;

								/* convert command to integer */
								u8Cmd = (uint8_t)(u8Cmd * 10) + (uint8_t)u32StringToInt(cBuffer);

								/* Initialization of buffer */
								memset(cBuffer, 0, sizeof(cBuffer));

								/* count receive bytes */
								psMsgDecode->u8RcvByteCount++;

								/* Record the current time since the timer was started */
								psMsgDecode->u32CurentTime = psTimerInst->pfu32GetTickMs();
							}
							else
							{
								/* go to the header step */
								psMsgDecode->eState = PARSER_STATE_HEADER_U;
							}
						}
							break;

						default: break;
					}
				}
				else if ((u8ByteIn == PARSER_DELIMITER)           &&
						((u8Cmd    == ID_CMD_SET_TIME)            ||
						 (u8Cmd    == ID_CMD_RELAIS)              ||
						 (u8Cmd    == ID_CMD_SWITCH_REMOTE_RELAIS)))
				{
					/* Initialization of counter */
					u8ByteCnt = 0;

					/* set data length */
					u8DataLen = psMsgDecode->sFrame.u8DataLen - 1;

					if (psMsgDecode->sFrame.u8Cmd == ID_CMD_SET_TIME)
					{
						u8DataLen += 3;
					}

					/* fetch command */
					psMsgDecode->sFrame.u8Cmd = u8Cmd;

					/* go to the next step */
					psMsgDecode->eState = PARSER_STATE_DATA;

					/* Record the current time since the timer was started */
					psMsgDecode->u32CurentTime = psTimerInst->pfu32GetTickMs();
				}
				else if ((u8ByteIn == PARSER_END_OF_FRAME) && (u8ByteCnt != 0))
				{
					/* Initialization of counter */
					u8ByteCnt = 0;

					/* fetch command */
					psMsgDecode->sFrame.u8Cmd = u8Cmd;

					/* parsing is complete */
					psMsgDecode->eState = PARSER_STATE_COMPLETE;

					/* Initialization of byte counter for the next parsing */
					psMsgDecode->u8RcvByteCount = 0;
				}
				else
				{
					/* go to the next step */
					psMsgDecode->eState = PARSER_STATE_HEADER_U;
				}
			}
			else
			{
				/* go to the next step */
				psMsgDecode->eState = PARSER_STATE_HEADER_U;
			}

			break;
		}

		case PARSER_STATE_DATA :
		{
			/* compute elapse time */
			psMsgDecode->u32ElapseTime = (psTimerInst->pfu32GetTickMs() - psMsgDecode->u32CurentTime);

			/* check if time elapsed */
			if (psMsgDecode->u32ElapseTime <= UART_TIME_OUT)
			{
				if ((u8ByteIn >= '0') && (u8ByteIn <= '9'))
				{
					if ((u8Cmd == ID_CMD_SET_TIME) && (u8ByteCnt < 10))
					{
						/* fetch data */
						cBuffer[psMsgDecode->u8BufferIndex] = u8ByteIn;

						/* Increment index */
						psMsgDecode->u8BufferIndex++;

						/* increment counter */
						u8ByteCnt++;

						/* Record the current time since the timer was started */
						psMsgDecode->u32CurentTime = psTimerInst->pfu32GetTickMs();
					}
					else if (((u8Cmd == ID_CMD_RELAIS)   ||
							(u8Cmd == ID_CMD_SWITCH_REMOTE_RELAIS)) &&
							(u8ByteCnt < 3))
					{
						cBuffer[0] = u8ByteIn;

						/* fetch data */
						psMsgDecode->sFrame.u8Data[psMsgDecode->u8BufferIndex] = psMsgDecode->sFrame.u8Data[psMsgDecode->u8BufferIndex] * 10 + (uint8_t)u32StringToInt(cBuffer);

						/* Initialization of buffer */
						memset(cBuffer, 0, sizeof(cBuffer));

						if ((psMsgDecode->sFrame.u8Cmd == ID_CMD_SET_TIME) && (u8ByteCnt == 3))
						{
							psMsgDecode->u8BufferIndex++;
						}

						/* increment counter */
						u8ByteCnt++;

						/* Record the current time since the timer was started */
						psMsgDecode->u32CurentTime = psTimerInst->pfu32GetTickMs();
					}
					else
					{
						/* return to the header state */
						psMsgDecode->eState = PARSER_STATE_HEADER_U;
					}
				}
				else if ((u8ByteIn == PARSER_DELIMITER) && (u8ByteCnt != 0) && (psMsgDecode->u8BufferIndex < u8DataLen))
				{
					/* Initialization of counter */
					u8ByteCnt = 0;

					/* go to the next index */
					if (psMsgDecode->sFrame.u8Cmd != ID_CMD_SET_TIME)
					{
						psMsgDecode->u8BufferIndex++;
					}

					/* Record the current time since the timer was started */
					psMsgDecode->u32CurentTime = psTimerInst->pfu32GetTickMs();
				}
				else if ((u8ByteIn == PARSER_END_OF_FRAME) && (u8ByteCnt != 0))
				{
					/* parsing is complete */
					psMsgDecode->eState = PARSER_STATE_COMPLETE;

					if (u8Cmd == ID_CMD_SET_TIME)
					{
						/* compute unix time */
						sUnixTime.u32LongWord = u32StringToInt(cBuffer);

						/* Initialization of buffer */
						memset(cBuffer, 0, sizeof(cBuffer));

						/* fetch unix time */
						psMsgDecode->sFrame.u8Data[0] = sUnixTime.u8Byte[0];
						psMsgDecode->sFrame.u8Data[1] = sUnixTime.u8Byte[1];
						psMsgDecode->sFrame.u8Data[2] = sUnixTime.u8Byte[2];
						psMsgDecode->sFrame.u8Data[3] = sUnixTime.u8Byte[3];
					}

					/* Initialization of byte counter */
					psMsgDecode->u8RcvByteCount = 0;
				}
				else
				{
					/* return to the header state */
					psMsgDecode->eState = PARSER_STATE_HEADER_U;
				}
			}
			else
			{
				/* return to the header state */
				psMsgDecode->eState = PARSER_STATE_HEADER_U;
			}

			break;
		}

		default :
			break;
	}
}


static void vSendResp(const sRcvFrame_t *sRcvMsg)
{
	uint8_t u8Index      = u8GetCmdIndex(sRcvMsg->u8Cmd);
	uint8_t u8Byte2      = u8GetByte2(sRcvMsg->u8Cmd);
	uint8_t u8DataLen    = u8GetRespLen(sRcvMsg->u8Cmd);

	/* Initialization of tx buffers */
	memset(&u8DataToSend[0], 0, sizeof(u8DataToSend));
	memset(&u8UartTxBuffer[0], 0, sizeof(u8UartTxBuffer));


	/* Insert header*/
	u8DataToSend[0] = 'P';
	u8DataToSend[1] = 'C';
	u8DataToSend[2] = '_';
	u8DataToSend[3] = ';';

	/* Insert byte 2 */
	u8DataToSend[4] = u8Byte2;
	u8DataToSend[5] = ';';

	/* Insert command ID */
	u8DataToSend[6] = sRcvMsg->u8Cmd;

	/* call the corresponding function */
	if (cmdParser[u8Index].vFunc != NULL_PTR)
	{
		(cmdParser[u8Index].vFunc)(&sRcvMsg->u8Data[0], &u8UartTxBuffer[0]);
	}

	/* Insert data */
	if (u8DataLen >= DATA_LENGHT_MIN)
	{
		switch (sRcvMsg->u8Cmd)
		{
			case ID_CMD_READ_ADC :
			{
				/* set semi-colon */
				u8DataToSend[7] = ';';

				/* fetch status */
				u8DataToSend[8] = u8UartTxBuffer[0];

				/* set semi-colon */
				u8DataToSend[9] = ';';

				/* fetch 5V raw ADC value */
				u8DataToSend[10]  = u8UartTxBuffer[1];
				u8DataToSend[11]  = u8UartTxBuffer[2];

				/* set semi-colon */
				u8DataToSend[12] = ';';

				/* fetch 24V raw ADC value */
				u8DataToSend[13] = u8UartTxBuffer[3];
				u8DataToSend[14] = u8UartTxBuffer[4];

				/* compute tx frame length */
				u8DataLen = HEADER_LEN + BYTE2_LEN + CMD_LEN + 10;
			}
				break;


			case ID_CMD_GET_TIME :
			{
				/* fetch semi-colon */
				u8DataToSend[7] = ';';

				/* fetch status */
				u8DataToSend[8] = u8UartTxBuffer[0];

				/* set semi-colon */
				u8DataToSend[9] = ';';

				/* fetch unix time */
				u8DataToSend[10] = u8UartTxBuffer[1];
				u8DataToSend[11] = u8UartTxBuffer[2];
				u8DataToSend[12] = u8UartTxBuffer[3];
				u8DataToSend[13] = u8UartTxBuffer[4];

				/* compute tx frame length */
				u8DataLen = HEADER_LEN + BYTE2_LEN + CMD_LEN + 9;
			}
				break;

			case ID_CMD_SWITCH_REMOTE_RELAIS :
			case ID_CMD_READ_ANALOG_INPUTS   : 
			case ID_CMD_RELAIS   :   
			case ID_CMD_I2C_TEST :           
			case ID_CMD_SET_TIME :
			{
				for (u8Index = 0; u8Index < (2 * u8DataLen); (u8Index += 2))
				{
					u8DataToSend[u8Index + 7] = ';';
					u8DataToSend[u8Index + 8] = u8UartTxBuffer[u8Index/2];
				}

				/* compute tx frame length */
				u8DataLen = HEADER_LEN + BYTE2_LEN + CMD_LEN + (2 * (u8DataLen + 1 ));
			}
				break;

			default : 
				break;
		}
	}
    
	/* transmit data */
	if(sRcvMsg->u8Cmd != ID_CMD_UPP_RESET)
	{
		/* send response */
		sUARTObj.pfvTriggerTx(u8DataLen, (u32)&u8DataToSend[0]);
	}
}


/********************************************************************************************************************
*													                                                                *
*	          D E F I N I T I O N        O F     P U B L I C         F U N C T I O N S                              *
*   													                                                            *
********************************************************************************************************************/

/* More details in header file */
void vRcvMsg(void)
{
	/* initialize variable to parse received data */
	sUartRxBuffer.u16WriteIndex  = sUARTObj.pfu16GetRcvIdx();

	while (sUartRxBuffer.u16ReadIndex != sUartRxBuffer.u16WriteIndex)
	{
		/* Parse receive data */
		vMsgDeserialize((sRawMessageDecode_t*)&sMsgDecode, sUartRxBuffer.u8Data[sUartRxBuffer.u16ReadIndex]);

		if (sMsgDecode.eState == PARSER_STATE_COMPLETE)
		{
			/* Send response */
			vSendResp((sRcvFrame_t *)&sMsgDecode.sFrame);

			/* Initialization of parser state */
			sMsgDecode.eState = PARSER_STATE_HEADER_U;
		}

		/* When we try to increment read index and we reach the end of buffer,
		 * we start from the beginning of the buffer */
		if (sUartRxBuffer.u16ReadIndex == UART_BUFFER_SIZE - 1)
		{
			sUartRxBuffer.u16ReadIndex = 0;
		}
		else
		{
			sUartRxBuffer.u16ReadIndex++;
		}
	}
}


/* More details in header file */
void vParserInit(const sTIMObj_t *psTimerObj)
{
	/* Initialization of raw decode message */
	memset((void*)&sMsgDecode, 0, sizeof(sRawMessageDecode_t));

	/* Initialization of rx buffer */
	memset((void*)&sUartRxBuffer, 0, sizeof(sUartBuffer_t));

	/* fetch timer object */
	psTimerInst = psTimerObj;

	/* Configure UART to receive data */
	sUARTObj.eUartParams   = UART_115K2_8b_NONE_ONE;
	sUARTObj.u32RcvBuffer  = (uint32_t)&sUartRxBuffer.u8Data[0];
	sUARTObj.u16RcvDmaSize = UART_BUFFER_SIZE;

	/* Initialization of UART */
	vUartInit(&sUARTObj);

	/* Initialization of ADC */
	vADCInit(&sADCObj, psTimerObj);

    /* Initialization of port expander */
    vPcf8574Init(PCF8574_ADDR0, &hi2c1);

    /* Initialization of RTC */
    bM41t56Init(&hi2c1);

	/* Initialization of UPP GPIO */
	vUPPGPIOInit();
}


